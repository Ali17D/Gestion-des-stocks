package server;

import java.net.*;
import java.util.*;

import model.Medicament;

import java.io.*;

public class Gestion extends Thread{
	private Socket s;

	public Gestion(Socket s) {
		this.s = s;
	}
	public void run(){
		try {
			InputStreamReader in = new InputStreamReader(s.getInputStream());
	        BufferedReader in_sc = new BufferedReader(in);
	
	        OutputStreamWriter out = new OutputStreamWriter(s.getOutputStream());
	        PrintWriter out_sc = new PrintWriter(new BufferedWriter(out), true);
	        while(true) {
	        	String msg=in_sc.readLine();
	        	if(msg.startsWith("ADD ")) {
	        		String cd=msg.substring(4);
	        		String[] t=cd.split(" ");
	        		boolean test=false;
	        		for(Medicament med: ServerMed.listMed) {
	        			if(med.getDesc().equals(t[0])) {
	        				test=true;
	        			}
	        		}
	        		if(test==true) {
	        			out_sc.println("Le medoc existe d�ja");
	        		}
	        		else {
        				Calendar c=Calendar.getInstance();
        				int annee_c=c.get(Calendar.YEAR);
        				int mois_c=c.get(Calendar.MONTH);
        				int a=Integer.parseInt(t[2]);
        				int m=Integer.parseInt(t[1]);
        				if(a>annee_c || (a==annee_c && m>mois_c)) {
        					Medicament med1=new Medicament(t[0], m, a, Integer.parseInt(t[3]));
        					ServerMed.listMed.add(med1);
        					out_sc.println("Medoc ajout� avec succ�s");
        				}
        				else {
        					out_sc.println("Medoc expir�");
        				}
	        		}
	        	}
	        	else if(msg.equals("LIST")) {
        			String s="";
        			for(Medicament med:ServerMed.listMed) {
        				s+=med.info()+"///";
        			}
        			if(s.length()>0) {
        				out_sc.println(s);
        			}
        			else {
        				out_sc.println("Aucun medoc dispo");
        			}
	        	}
	        	else if(msg.equals("LISTPRE")) {
        			String s="";
    				Calendar c=Calendar.getInstance();
    				int annee_c=c.get(Calendar.YEAR);
    				int mois_c=c.get(Calendar.MONTH);
        			for(Medicament med:ServerMed.listMed) {
        				if(med.getAnnee()<annee_c || (med.getAnnee()==annee_c && med.getMois()<=mois_c)) {
            				s+=med.info()+"///";
        				}
        			}
        			if(s.length()>0) {
        				out_sc.println(s);
        			}
        			else {
        				out_sc.println("Aucun medoc p�rim�");
        			}
	        	}
	        	else if(msg.startsWith("CHERCHER ")) {
	        		boolean test=false;
	        		for(Medicament med: ServerMed.listMed) {
	        			if(med.getDesc().equals(msg.substring(9))) {
	        				out_sc.println(med.info());
		        			test=true;
	        			}
	        		}
	        		if(test==false) {
	        			out_sc.println("Medoc introuvable");
	        		}
	        	}
	        	else if(msg.startsWith("DELETE ")) {
	        		boolean test=false;
	        		for(Medicament med: ServerMed.listMed) {
	        			if(med.getDesc().equals(msg.substring(7))) {
	        				ServerMed.listMed.remove(med);
		        			test=true;
	        			}
	        		}
	        		if(test==true) {
	        			
	        			out_sc.println("Medoc supprim� avec succ�s");
	        		}
	        		else {
	        			out_sc.println("Medoc inexistant");
	        		}
	        	}
	        	else if(msg.equals("CURRENT")) {
    				Calendar c=Calendar.getInstance();
    				int annee_c=c.get(Calendar.YEAR);
    				int mois_c=c.get(Calendar.MONTH);
        			out_sc.println(mois_c+"/"+annee_c);
	        	}
	        	else {
        			out_sc.println("Wrong Syntax");
	        	}
        	}
		}
		catch(Exception e) {
			
		}
	}
}

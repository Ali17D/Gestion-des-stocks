package model;

public class Medicament {
	private String desc;
	private int mois;
	private int annee;
	private int qte;
	public Medicament(String desc, int mois, int annee, int qte) {
		this.desc = desc;
		this.mois = mois;
		this.annee = annee;
		this.qte = qte;
	}
	public String info() {
		return desc+"|"+mois+"/"+annee+"|"+qte;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public int getMois() {
		return mois;
	}
	public void setMois(int mois) {
		this.mois = mois;
	}
	public int getAnnee() {
		return annee;
	}
	public void setAnnee(int annee) {
		this.annee = annee;
	}
	public int getQte() {
		return qte;
	}
	public void setQte(int qte) {
		this.qte = qte;
	}
}
